# Evaluacion Final Java Web
> Sprint final modulo 5
Proyecto final para completar el modulo de Desarrollo de aplicaciones web dinámicas java

Autores: Piero Vaccaro - Diego Pérez - Cristobal Arevalo

## Repositorio de los integrantes
* https://github.com/diegoperezm/M5SprintFinal.git
* https://github.com/carevalo07/M5SprintFinal.git
* https://github.com/PieroVaccaro/M5SprintFinal.git
  
## Como ejecutar programa?
* Descargar todos los archivos de este repositorio
```git clone https://github.com/carevalo07/M5SprintFinal.git ```
* Ejecutar el archivo en conjunto con servidor Apache

## Caracteristicas

La pagina web contiene las siguientes paginas:
* Login
* Crear usuario
* Listar usuario
* Editar usuario
* Crear capacitación
* Listar capacitación
* Contacto
